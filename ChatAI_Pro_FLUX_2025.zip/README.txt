ChatAI Pro FLUX 2025 — Groq + Voce + Immagini (Hugging Face Router)

Avvio locale:
  pip install -r requirements.txt
  python app.py

Per Render:
  Start Command: web: python server.py
